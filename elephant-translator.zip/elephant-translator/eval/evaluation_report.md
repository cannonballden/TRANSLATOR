# Evaluation report
Run `python tests/run_tests.py` after fetching media.
